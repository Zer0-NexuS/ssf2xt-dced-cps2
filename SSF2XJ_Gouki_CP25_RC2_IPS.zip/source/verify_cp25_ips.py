#!/usr/bin/env python3
"""Independently apply every delivered IPS and exercise the user-facing helper."""
from pathlib import Path
import argparse,hashlib,importlib.util,io,json,subprocess,sys,tempfile,zipfile

def digest(data):return hashlib.sha256(data).hexdigest()
def independent_apply(source,patch):
    reader=io.BytesIO(patch);assert reader.read(5)==b'PATCH';out=bytearray(source)
    while True:
        marker=reader.read(3);assert len(marker)==3
        if marker==b'EOF':
            footer=reader.read();assert len(footer)in (0,3)
            if footer:
                size=int.from_bytes(footer,'big');out=out[:size]+bytes(max(0,size-len(out)))
            return bytes(out)
        offset=int.from_bytes(marker,'big');word=reader.read(2);assert len(word)==2
        length=int.from_bytes(word,'big')
        if length:payload=reader.read(length)
        else:
            count=reader.read(2);value=reader.read(1);assert len(count)==2 and len(value)==1
            length=int.from_bytes(count,'big');payload=value*length
        assert length and len(payload)==length
        out.extend(bytes(max(0,offset+length-len(out))));out[offset:offset+length]=payload

def main():
    p=argparse.ArgumentParser();p.add_argument('stock',type=Path);p.add_argument('target',type=Path);p.add_argument('package',type=Path);a=p.parse_args()
    stock,target,package=a.stock.resolve(),a.target.resolve(),a.package.resolve()
    manifest=json.loads((package/'patch_manifest.json').read_text());assert digest(stock.read_bytes())==manifest['source_zip_sha256']
    assert digest(target.read_bytes())==manifest['target_zip_sha256']
    checks=[]
    direct=independent_apply(stock.read_bytes(),(package/manifest['archive_patch']['file']).read_bytes())
    assert direct==target.read_bytes();checks.append('Independent ZIP IPS application: complete archive byte-identical to CP25_RC1')
    with zipfile.ZipFile(stock)as src,zipfile.ZipFile(target)as dst:
        base={n:src.read(n)for n in src.namelist()}
        for r in manifest['members']:
            value=base[r['name']]
            if r['patch']:value=independent_apply(value,(package/r['patch']['file']).read_bytes())
            assert value==dst.read(r['name'])
    checks.append('Independent member IPS application: all 25 ROM files byte-identical to CP25_RC1')
    with tempfile.TemporaryDirectory(prefix='ssf2x-ips-verify-')as td:
        temp=Path(td)
        def run(source,destination,extra=(),success=True,folder=package):
            result=subprocess.run([sys.executable,str(folder/'apply_cp25.py'),str(source),'--output',str(destination),*extra],capture_output=True,text=True)
            assert (result.returncode==0)==success,result.stdout+result.stderr
            return result
        for tag,args in [('ZIP',()),('member',('--member-ips',))]:
            output=temp/(tag+'.zip');run(stock,output,args);assert output.read_bytes()==target.read_bytes()
            checks.append('Helper '+tag+' IPS method: complete archive byte-identical to CP25_RC1')
        repacked=temp/'repacked.zip'
        with zipfile.ZipFile(repacked,'w',zipfile.ZIP_DEFLATED,compresslevel=1)as z:
            for name in reversed(list(base)):z.writestr('original/'+name,base[name])
        output=temp/'repacked-output.zip';run(repacked,output);assert output.read_bytes()==target.read_bytes()
        checks.append('Helper repacked/nested stock archive: complete archive byte-identical to CP25_RC1')
        existing=temp/'existing.zip';existing.write_bytes(b'KEEP')
        run(stock,existing,success=False);assert existing.read_bytes()==b'KEEP';checks.append('Existing output rejected and preserved')
        run(stock,stock,success=False);assert digest(stock.read_bytes())==manifest['source_zip_sha256'];checks.append('In-place write rejected; original source preserved')
        run(target,temp/'already-patched.zip',success=False);assert not (temp/'already-patched.zip').exists();checks.append('Already-patched source rejected')
        wrong=temp/'wrong.zip'
        with zipfile.ZipFile(wrong,'w',zipfile.ZIP_STORED)as z:
            for name,data in base.items():z.writestr(name,bytes([data[0]^1])+data[1:]if name=='sfxj.03d'else data)
        run(wrong,temp/'wrong-output.zip',success=False);assert not (temp/'wrong-output.zip').exists();checks.append('Wrong or modified program ROM rejected')
        incomplete=temp/'incomplete.zip'
        with zipfile.ZipFile(incomplete,'w',zipfile.ZIP_STORED)as z:
            for name,data in base.items():
                if name!='sfx.21m':z.writestr(name,data)
        run(incomplete,temp/'incomplete-output.zip',success=False);checks.append('Incomplete source ROM set rejected')
        damaged=temp/'damaged';damaged.mkdir()
        for name in ('apply_cp25.py','patch_manifest.json'):(damaged/name).write_bytes((package/name).read_bytes())
        patch=(package/manifest['archive_patch']['file']).read_bytes();(damaged/manifest['archive_patch']['file']).write_bytes(patch[:-1]+bytes([patch[-1]^1]))
        run(stock,temp/'damaged-output.zip',success=False,folder=damaged);checks.append('Damaged IPS rejected by checksum')
    # Important format boundaries: long records, EOF as an offset, grow/shrink and RLE.
    spec=importlib.util.spec_from_file_location('generator',Path(__file__).with_name('create_cp25_ips.py'))
    generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
    fixtures=[(bytes(70000),b'x'*70000),(b'abcdef',b'abc'),(b'abc',b'abcdef'),(bytes(0x454f50),bytes(0x454f46)+b'XYZ'+bytes(7))]
    for before,after in fixtures:assert independent_apply(before,generator.make_ips(before,after))==after
    assert independent_apply(b'abc',b'PATCH'+b'\x00\x00\x01\x00\x00\x00\x03Z'+b'EOF')==b'aZZZ'
    checks.append('IPS record size, reserved EOF offset, resize and RLE boundaries verified')
    report={'status':'PASS','release':'CP25 RC1','source_zip_sha256':manifest['source_zip_sha256'],
        'target_zip_sha256':manifest['target_zip_sha256'],'member_count':25,'member_patch_count':7,
        'checks':checks,'Windows_launcher_execution':'Not run on Windows; launcher invokes the verified Python helper',
        'gameplay_scope':'No ROM changes: patched output is identical to the already validated CP25_RC1 release'}
    (package/'PATCH_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
if __name__=='__main__':main()
