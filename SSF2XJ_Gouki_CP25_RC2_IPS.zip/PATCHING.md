# SSF2XJ Gouki CP25 RC1 — stock ROM upgrade

This package upgrades the original Japanese **SSF2XJ** CPS2 ROM set directly to
CP25 RC1. It includes all Gouki/Shin Gouki/Ten Gouki integration, moves, meters,
names, ending, intro/warning fixes, service TITLE choices and final Dreamcast
emblem/shadow spacing, plus saved FREE PLAY selection in the COIN setting. The USA-selected intro blackout is also corrected. The new normal and injured Gouki portraits are also included. Retail-style framed blue Gouki HUD portraits, corrected two-way intro scene handoffs and black Dreamcast subtitle reveal squares are included. The lettering retains its colors. An earlier patched build is not required.

## Recommended: patch your ROM ZIP

Extract this package. Python 3 is required for the helper.

On Windows, drag your original `ssf2xj.zip` onto `Apply_CP25_RC1.bat`.
On macOS/Linux, or from a terminal:

```sh
python3 apply_cp25.py "/path/to/original/ssf2xj.zip"
```

The verified result is written to **`Gouki_CP25_RC1/ssf2xj.zip` beside your original**.
The helper checks all 25 ROM members and all patch hashes. It accepts the exact
original archive or a repacked archive containing the same complete stock ROMs.
It rejects a different revision, incomplete set, already-patched files, in-place
writes and existing output files. The original is preserved. Shared ROM and key
files, including `dl-1425.bin`, must be present in a complete source ZIP.

To choose a different new output:

```sh
python3 apply_cp25.py original/ssf2xj.zip --output patched/ssf2xj.zip
```

## Apply one IPS directly to the ZIP

With a conventional IPS patcher, apply
**`SSF2XJ_to_Gouki_CP25_RC1_ZIP.ips` to the original ZIP file itself**.
This direct method requires the exact original archive bytes:

```text
Original ZIP SHA-256:
ff6c7b1918938b6225ebccc8dba367655515b705c3c2c79c0412639806f702f0

Resulting CP25_RC1 ZIP SHA-256:
2f7b83f6abdc78b2ad2a1460d15180dd40879b0457159576c3fd501a1117b4bb
```

Use the helper for a repacked stock ZIP; its compressed bytes can differ even
when all original ROM contents are correct.

## Individual ROM-file patches

Alternatively, extract the stock ROM set, apply each patch below to its matching
**extracted file**, and re-create `ssf2xj.zip` with all 25 files at the ZIP root.
These seven patches are in `member_ips/`. The other 18 ROM files stay unchanged.

| IPS file | Original extracted ROM file |
| --- | --- |
| `sfxj.03d.ips` | `sfxj.03d` |
| `sfxj.04a.ips` | `sfxj.04a` |
| `sfx.09.ips` | `sfx.09` |
| `sfx.21m.ips` | `sfx.21m` |
| `sfx.23m.ips` | `sfx.23m` |
| `sfx.25m.ips` | `sfx.25m` |
| `sfx.27m.ips` | `sfx.27m` |

The required retail program revision has `sfxj.03d` CRC32 `50b52b37` and
`sfxj.04a` CRC32 `af7767b4`. Complete source/target hashes are in
`patch_manifest.json`; application results are in `PATCH_VERIFICATION.json`.
The ZIP IPS and chip IPS files are separate application methods; use one method.

The patched ROM bytes match the released CP25_RC1 build. Generic IPS patchers do not
check source hashes; the included helper does. ROM modifications may produce
the expected stock-checksum warnings in emulators. This patch package does not
change the game beyond the already validated CP25_RC1 release.
