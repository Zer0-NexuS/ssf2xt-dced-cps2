#!/usr/bin/env python3
"""Apply the verified stock-SSF2XJ-to-RC5 IPS package. Python standard library only."""
import argparse,base64,hashlib,json,os,tempfile,zipfile
from pathlib import Path,PurePosixPath

def sha(data):return hashlib.sha256(data).hexdigest()

def apply_ips(source,patch):
    if patch[:5]!=b'PATCH':raise ValueError('Invalid IPS header')
    result=bytearray(source);cursor=5
    def take(n):
        nonlocal cursor
        if cursor+n>len(patch):raise ValueError('Truncated IPS record')
        value=patch[cursor:cursor+n];cursor+=n;return value
    while True:
        marker=take(3)
        if marker==b'EOF':
            remaining=len(patch)-cursor
            if remaining==3:
                size=int.from_bytes(take(3),'big')
                result=result[:size]+bytes(max(0,size-len(result)))
            elif remaining:raise ValueError('Unexpected data after IPS EOF')
            return bytes(result)
        offset=int.from_bytes(marker,'big');size=int.from_bytes(take(2),'big')
        if size:data=take(size)
        else:
            size=int.from_bytes(take(2),'big')
            if not size:raise ValueError('Empty IPS RLE record')
            data=take(1)*size
        if offset+size>0x1000000:raise ValueError('IPS exceeds its 24-bit address space')
        if offset+size>len(result):result.extend(bytes(offset+size-len(result)))
        result[offset:offset+size]=data

def archive_members(path,manifest,which):
    with zipfile.ZipFile(path)as z:
        mapping={}
        for info in z.infolist():
            if info.is_dir():continue
            name=PurePosixPath(info.filename).name
            if name in mapping:raise ValueError('Duplicate ROM filename: '+name)
            mapping[name]=info
        expected={v['name']for v in manifest['members']}
        missing=expected-set(mapping)
        if missing:raise ValueError('Incomplete ROM set; missing: '+', '.join(sorted(missing)))
        result={}
        for record in manifest['members']:
            name=record['name'];data=z.read(mapping[name])
            if len(data)!=record[which+'_size']or sha(data)!=record[which+'_sha256']:
                raise ValueError('Wrong '+which+' ROM revision or modified file: '+name)
            result[name]=data
        return result

def load_patch(folder,record):
    data=(folder/record['file']).read_bytes()
    if sha(data)!=record['sha256']:raise ValueError('Damaged patch: '+record['file'])
    return data

def write_member_archive(destination,members,manifest):
    with zipfile.ZipFile(destination,'w')as z:
        z.comment=base64.b64decode(manifest['target_zip_comment_b64'])
        for record in manifest['members']:
            m=record['zip_metadata'];info=zipfile.ZipInfo(record['name'],tuple(m['date_time']))
            for key in ('compress_type','create_system','create_version','extract_version','reserved','flag_bits','volume','internal_attr','external_attr'):
                setattr(info,key,m[key])
            info.extra=base64.b64decode(m['extra_b64']);info.comment=base64.b64decode(m['comment_b64'])
            z.writestr(info,members[record['name']])

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original',type=Path,help='Complete stock ssf2xj.zip, including shared ROM files')
    parser.add_argument('--output',type=Path,help='New output ZIP; default: Gouki_RC5/ssf2xj.zip beside the original')
    parser.add_argument('--member-ips',action='store_true',help='Use individual ROM IPS files even for the exact original ZIP')
    args=parser.parse_args();source=args.original.resolve()
    output=(args.output or source.parent/'Gouki_RC5/ssf2xj.zip').resolve()
    if source==output:raise ValueError('Output must differ from the original ROM ZIP')
    if output.exists():raise ValueError('Output already exists; choose a new output path: '+str(output))
    folder=Path(__file__).resolve().parent;manifest=json.loads((folder/'patch_manifest.json').read_text())
    original=archive_members(source,manifest,'source')
    output.parent.mkdir(parents=True,exist_ok=True)
    handle,tempname=tempfile.mkstemp(prefix='.ssf2xj-rc5-',suffix='.zip',dir=output.parent);os.close(handle)
    temporary=Path(tempname)
    try:
        if not args.member_ips and sha(source.read_bytes())==manifest['source_zip_sha256']:
            patched=apply_ips(source.read_bytes(),load_patch(folder,manifest['archive_patch']))
            if sha(patched)!=manifest['target_zip_sha256']:raise ValueError('Patched ZIP does not match RC5')
            temporary.write_bytes(patched);method='ZIP IPS'
        else:
            for record in manifest['members']:
                if record['patch']:
                    original[record['name']]=apply_ips(original[record['name']],load_patch(folder,record['patch']))
                if sha(original[record['name']])!=record['target_sha256']:
                    raise ValueError('Patched ROM verification failed: '+record['name'])
            write_member_archive(temporary,original,manifest);method='member IPS'
        archive_members(temporary,manifest,'target')
        # Atomic no-overwrite publication; the original file is never opened for writing.
        os.link(temporary,output)
    finally:temporary.unlink(missing_ok=True)
    print('Created '+str(output))
    print('Verified all '+str(len(manifest['members']))+' RC5 ROM files using '+method+'.')
    print('ZIP SHA-256: '+sha(output.read_bytes()))

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,zipfile.BadZipFile,KeyError)as error:
        raise SystemExit('Patch not applied: '+str(error))
