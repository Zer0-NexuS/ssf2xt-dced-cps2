@echo off
setlocal
set "SSF2XJ_INPUT=%~1"
if "%SSF2XJ_INPUT%"=="" set "SSF2XJ_INPUT=%~dp0ssf2xj.zip"
py -3 --version >nul 2>&1
if errorlevel 1 (
  python "%~dp0apply_rc5.py" "%SSF2XJ_INPUT%"
) else (
  py -3 "%~dp0apply_rc5.py" "%SSF2XJ_INPUT%"
)
pause
