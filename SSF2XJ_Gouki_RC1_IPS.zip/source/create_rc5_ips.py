#!/usr/bin/env python3
"""Create conventional ZIP-level and chip-level IPS files from verified retail ROMs."""
from pathlib import Path
import argparse,base64,hashlib,json,shutil,zipfile
import numpy as np
SOURCE_SHA='ff6c7b1918938b6225ebccc8dba367655515b705c3c2c79c0412639806f702f0'
TARGET_SHA='943e9692b293681149038ba6a7e4c26631469b6f0d6a718c80d5b35d2f1fa180'
def sha(data):return hashlib.sha256(data).hexdigest()
def make_ips(source,target):
    if max(len(source),len(target))>0x1000000:raise ValueError('IPS 24-bit size limit exceeded')
    equal=np.zeros(len(target),bool);common=min(len(source),len(target))
    equal[:common]=np.frombuffer(source[:common],np.uint8)==np.frombuffer(target[:common],np.uint8)
    indices=np.flatnonzero(~equal);result=bytearray(b'PATCH')
    if len(indices):
        splits=np.flatnonzero(np.diff(indices)>6)+1
        starts=np.r_[indices[0],indices[splits]];ends=np.r_[indices[splits-1]+1,indices[-1]+1]
        for start,end in zip(starts,ends):
            start,end=int(start),int(end)
            while start<end:
                # The reserved EOF offset must never begin a literal record.
                record_start=start-1 if start==0x454f46 else start
                stop=min(end,record_start+65535)
                result.extend(record_start.to_bytes(3,'big'));result.extend((stop-record_start).to_bytes(2,'big'))
                result.extend(target[record_start:stop]);start=stop
    result.extend(b'EOF')
    if len(target)<len(source):result.extend(len(target).to_bytes(3,'big'))
    return bytes(result)
def main():
    p=argparse.ArgumentParser();p.add_argument('stock',type=Path);p.add_argument('target',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    stock,target=a.stock.read_bytes(),a.target.read_bytes()
    assert sha(stock)==SOURCE_SHA and sha(target)==TARGET_SHA
    a.output.mkdir(parents=True,exist_ok=True);(a.output/'member_ips').mkdir(exist_ok=True)
    archive_name='SSF2XJ_to_Gouki_CP21_RC5_ZIP.ips';archive_patch=make_ips(stock,target)
    (a.output/archive_name).write_bytes(archive_patch)
    manifest={'release':'CP21 RC5','source_set':'Retail SSF2XJ (sfxj.03d / sfxj.04a)',
        'source_zip_sha256':SOURCE_SHA,'target_zip_sha256':TARGET_SHA,
        'source_zip_library_file_id':'libfile_5c2d137dbf64819198484de3998ecdda',
        'target_rom_library_file_id':'libfile_0771a55e48b88191b9f6936976c4972f',
        'archive_patch':{'file':archive_name,'sha256':sha(archive_patch),'size':len(archive_patch)},'members':[]}
    with zipfile.ZipFile(a.stock)as src,zipfile.ZipFile(a.target)as dst:
        assert src.namelist()==dst.namelist()
        manifest['target_zip_comment_b64']=base64.b64encode(dst.comment).decode()
        for info in dst.infolist():
            name=info.filename;before,after=src.read(name),dst.read(name);record=None
            if before!=after:
                patch=make_ips(before,after);filename='member_ips/'+name+'.ips';(a.output/filename).write_bytes(patch)
                record={'file':filename,'sha256':sha(patch),'size':len(patch)}
            metadata={key:getattr(info,key)for key in ('date_time','compress_type','create_system','create_version','extract_version','reserved','flag_bits','volume','internal_attr','external_attr')}
            metadata.update(extra_b64=base64.b64encode(info.extra).decode(),comment_b64=base64.b64encode(info.comment).decode())
            manifest['members'].append({'name':name,'source_size':len(before),'target_size':len(after),
                'source_sha256':sha(before),'target_sha256':sha(after),'source_CRC32':f'{src.getinfo(name).CRC:08x}',
                'target_CRC32':f'{info.CRC:08x}','patch':record,'zip_metadata':metadata})
    (a.output/'patch_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    here=Path(__file__).resolve().parent
    shutil.copyfile(here/'apply_rc5_ips.py',a.output/'apply_rc5.py')
    shutil.copyfile(here/'RC5_IPS_README.md',a.output/'README.md')
    (a.output/'source').mkdir(exist_ok=True)
    for filename in ('create_rc5_ips.py','apply_rc5_ips.py','RC5_IPS_README.md','verify_rc5_ips.py'):
        shutil.copyfile(here/filename,a.output/'source'/filename)
    (a.output/'Apply_RC5.bat').write_bytes(b'@echo off\r\nsetlocal\r\nset "SSF2XJ_INPUT=%~1"\r\nif "%SSF2XJ_INPUT%"=="" set "SSF2XJ_INPUT=%~dp0ssf2xj.zip"\r\npy -3 --version >nul 2>&1\r\nif errorlevel 1 (\r\n  python "%~dp0apply_rc5.py" "%SSF2XJ_INPUT%"\r\n) else (\r\n  py -3 "%~dp0apply_rc5.py" "%SSF2XJ_INPUT%"\r\n)\r\npause\r\n')
    print(json.dumps({'folder':str(a.output),'member_patches':[r['name']for r in manifest['members']if r['patch']],
        'ZIP_IPS_bytes':len(archive_patch),'member_IPS_total_bytes':sum(r['patch']['size']for r in manifest['members']if r['patch'])}))
if __name__=='__main__':main()
